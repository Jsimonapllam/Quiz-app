# Quiz App
Quiz App is an Android app in which users can play quizzes is 10 different categories with nearly 300 questions in total.

The salient features of the app are:
   1. Login is provided to the user so that only that person can access the app.
   2. Timer for the quiz to make the quizzing more interesting.
   3. User can see own best score in different categories.
   4. App also has a beautiful sound option that can also be muted.
   
The app is designed with Google Material Design that supports the Android versions from Kitkat 4.4.0 to Naugat 7.7.1 and it's a fork of the QuizBook App.


### You can download the .apk file of the project at: https:https://drive.google.com/file/d/1CIJ31CRhGRz7Os8va54VLNV49jfkqgDG/view?usp=drivesdk

